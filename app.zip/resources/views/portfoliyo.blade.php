@extends('layouts.app')
@section('meta_title','')


@section('content')
<div class="rs-breadcrumbs img1">
                <div class="breadcrumbs-inner text-center">
                    <h1 class="page-title">Portfoliyo</h1>
                    <ul>
                        <li title="#">
                            <a class="active" href="/">Home</a>
                        </li>
                        <li>Portfoliyo</li>
                    </ul>
                </div>
            </div>
            <!-- Breadcrumbs End -->

       

@endsection