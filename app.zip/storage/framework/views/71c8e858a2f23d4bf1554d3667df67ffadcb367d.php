<?php $__env->startSection('meta_title',$category->name); ?>
<?php $__env->startSection('meta_keywords',$category->name); ?>
<?php $__env->startSection('meta_description',$category->name); ?>
<?php $__env->startSection('meta_image'); ?>
<?php if($category->image): ?>
content="<?php echo e(Request::root()); ?>/storage/<?php echo e($category->image); ?>"
<?php else: ?>
content="<?php echo e(Request::root()); ?>/images/logo-2.png"
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="rs-breadcrumbs img3">
   <div class="breadcrumbs-inner text-center">
      <h1 class="page-title"><?php echo e($category->name); ?></h1>
      <ul>
         <li title="<?php echo e($category->name); ?>">
            <a class="active" href="/">Home</a>
         </li>
         <li title="Go To Services">
            <a class="active" href="#"> <?php echo e($category->name); ?></a>
         </li>
         <li><?php echo e($category->name); ?></li>
      </ul>
   </div>
   <p></p>
</div>
<section class=" pb-80">
   <div class="container">
      <div class="row">
         
         <div class="col-sm-12 col-md-12 col-lg-3">
            <div class="sidebar-cat">
               <h4 class="catr">All Categories</h4>
               <div class="list-group">
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($category->id == $item->id): ?>
                  <a href="<?php echo e($item->slug); ?>" class="active">
                  <?php echo e($item->name); ?>

                  </a>
                  <?php else: ?>
                  <a href="<?php echo e($item->slug); ?>" class="">
                  <?php echo e($item->name); ?>

                  </a>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
            <div class="form-groups">
               <h4 class="catr">Enquiry Now</h4>
               <form  class="row" method="post" action="/enquiry/store">
                  <?php echo csrf_field(); ?>
                  <div id="formmessage"></div>
                  <div class="form-group col-md-12">
                     <input id="form_name" type="text" name="name" class="form-control" placeholder="Name" required="required">
                  </div>
                  <div class="form-group col-md-12">
                     <input id="form_email" type="email" name="email" class="form-control" placeholder="Email" required="required">
                  </div>
                  <div class="form-group col-md-12">
                     <input id="form_phone" type="tel" name="phone" class="form-control" placeholder="Phone" required="required">
                  </div>
                  <div class="form-group col-md-12">
                     <select name="about" class="form-select form-control">
                        <option>Choose Service</option>
                        <option>Digital Marketing</option>
                        <option>Seo Service</option>
                     </select>
                  </div>
                  <div class="form-group col-md-12">
                     <textarea id="form_message" name="message" class="form-control" placeholder="Message" rows="3" required="required"></textarea>
                  </div>
                  <div class="col-md-12 text-center mt-4">
                     <button class="btn btn-theme" type><span>Send Messages</span>
                     </button>
                  </div>
               </form>
            </div>
         </div>
         <div class="col-lg-9 col-md-12">
            <div class="row">
               <?php if(count($products)>0): ?>
               <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-lg-4">
                  <div class="content-type">
                     <img src="/<?php echo e($pro->image); ?>">
                     <div class="bcont">
                        <h4><a href="<?php echo e($pro->slug); ?>"><?php echo e($pro->name); ?></a></h4>
                        <p><?php echo e(Str::limit($pro->composition, 50)); ?></p>
                     </div>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php else: ?>
               <h1>No results found..</h1>
               <?php endif; ?>
            </div>
         </div>
         <div class="col-lg-12">
            <div class="description">
               <p> <?php
                  echo html_entity_decode($category->description);
                  ?></p>
            </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/newrednirus/public_html/resources/views/PublicPages/category.blade.php ENDPATH**/ ?>