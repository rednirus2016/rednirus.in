<?php $__env->startSection('title','View Blogs'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-eye"></i>
                    View Blogs
                </div>
                <div class="card-body">
                    <?php if( Session::has('flash_message') ): ?>
                        <div class="alert alert-<?php echo e(Session::get('flash_type')); ?> alert-dismissible fade show" role="alert">
                            <b><?php echo e(Session::get('flash_message')); ?></b>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if(count($blogs)>0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover datatable datatable-User">
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Name</th>
                                        <th>Image</th>
                                        <th>Slug</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge badge-primary"><?php echo e($item2->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><img src="/public/images/blog/<?php echo e($item->image); ?>" width="200px" alt=""></td>
                                            <td><?php echo e($item->slug); ?></td>
                                            <td>
                                                <?php if($item->status): ?>
                                                    <a href="/admin/blogs/change-status/<?php echo e($item->id); ?>" onclick="return confirm('Are you sure you want to change status of this Blog?')" class="badge badge-success">Active</a>
                                                <?php else: ?>
                                                    <a href="/admin/blogs/change-status/<?php echo e($item->id); ?>" onclick="return confirm('Are you sure you want to change status of this Blog?')" class="badge badge-danger">Inactive</a>
                                                <?php endif; ?>    
                                            </td>
                                            <td>
                                                <a href="/admin/blogs/edit/<?php echo e($item->id); ?>" class="badge badge-primary"><i class="fas fa-pencil-alt"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo e($blogs->links()); ?>

                    <?php else: ?>
                        <h6>No Blogs Found.</h6>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/newrednirus/public_html/resources/views/Blog/view.blade.php ENDPATH**/ ?>