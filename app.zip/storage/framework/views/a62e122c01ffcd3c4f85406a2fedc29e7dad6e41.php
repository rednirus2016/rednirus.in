<table style="border-collapse: collapse; width: 100%; height: 90px;" border="">
<tbody>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>name </strong></td>
<td style="width: 50%; height: 18px; text-align: center;"><?php echo e($data["name"]); ?></td>
</tr>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>Email</strong></td>
<td style="width: 50%; height: 18px; text-align: center;"><?php echo e($data["email"]); ?></td>
</tr>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>subject</strong></td>
<td style="width: 50%; height: 18px; text-align: center;"><?php echo e($data["subject"]); ?></td>
</tr>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>Phone</strong></td>
<td style="width: 50%; height: 18px; text-align: center;"><?php echo e($data["mobile"]); ?></td>
</tr>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>Message</strong></td>
<td style="width: 50%; height: 18px; text-align: center;"><?php echo e($data["message"]); ?></td>
</tr>

</tbody>
</table>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php /**PATH /home1/newrednirus/public_html/resources/views/emails/Enquiry.blade.php ENDPATH**/ ?>