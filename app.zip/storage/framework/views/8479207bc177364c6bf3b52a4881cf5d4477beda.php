
<?php $__env->startSection('meta_title',' rednirus'); ?>
<?php $__env->startSection('meta_keywords','rednirus'); ?>
<?php $__env->startSection('meta_description','rednirus'); ?>
<?php $__env->startSection('meta_image'); ?>
content="<?php echo e(Request::root()); ?>/images/logo-2.png"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center mb-5">
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="wrapper">
                    <div class="row no-gutters">
                     

                        <div class="col-lg-12 col-md-7 order-md-last d-flex align-items-stretch">
                            <div class="contact-wrap w-100 p-md-5 p-4">
                               <img src="/public/assets/images/thamks.gif" style="width:205px; margin-left: 433px;">
                                <div id="form-message-warning" class="mb-4"></div>
                                <div id="form-message-success" class="mb-4" style="margin-left: 391px;font-size: 25px;">
                                    Your message was sent
                                </div>
                              
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/newrednirus/public_html/resources/views/PublicPages/contactus.blade.php ENDPATH**/ ?>