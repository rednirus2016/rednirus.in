<?php include('./constant/layout/head.php');?>
<?php include('./constant/layout/header.php');?>

<?php include('./constant/layout/sidebar.php');?>


<div class="page-wrapper">

  <div class="row page-titles">
    <div class="col-md-5 align-self-center">
      <h3 class="text-primary">Add Lead</h3>
    </div>
    <div class="col-md-7 align-self-center">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item active">Add Lead</li>
      </ol>
    </div>
  </div>


  <div class="container-fluid">




    <div class="row">
      <div class="col-lg-12 mx-auto">
        <div class="card">
          <div class="card-title">

          </div>
          <div id="add-brand-messages"></div>
          <div class="card-body">
            <div class="input-states">
              <form class="row" method="POST" id="submitBrandForm" action="php_action/addreview.php"
                enctype="multipart/form-data">
                
                <div class="form-group col-md-6">
                  <label class="control-label">Review</label>
                  <textarea class="form-control" id="message" name="review"></textarea>
                </div>
                
                 <?php 
                                       
                   $sql = "SELECT * FROM lead";
                   $result = $connect->query($sql);
                                            
                  ?>
                  
                  
                <div class="form-group col-md-6">
                  <label class="control-label">Leads</label>
                  <select class="form-control" id="categoriesStatus" name="lead_id">
                    <option> ~~Select Company~~</option>
                    <?php foreach ($result as $row) {
                                             ?>
                    <option value="<?php echo $row['id'] ?>">
                      <?php echo $row['company_name'] ?>
                    </option>
                     <?php   } ?>
                
                  </select>
                </div>
               
                
               
               
               
               
                

                <div class="form-group col-md-12">
                  <button type="submit" name="create" id="createCategoriesBtn"
                    class="btn btn-primary btn-flat m-b-30 m-t-30">Submit</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </div>





    <?php include('./constant/layout/footer.php');?>