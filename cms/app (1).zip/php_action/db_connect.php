<?php 	

$localhost = "localhost";
$username = "rednirus_cms";
$password = "jR&Z+sys8J=T";
$dbname = "rednirus_cms";
$store_url = "https://redniruscare.com/cms";
// db connection
$connect = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}

?>